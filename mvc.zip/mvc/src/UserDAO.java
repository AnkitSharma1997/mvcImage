import mvc.LoginBeans;



import java.sql.*;
public class UserDAO {
	public static boolean login(LoginBeans user ){
		String userName = user.getUserName();
		String password = user.getPassword();
		String querry = "SELECT * FROM Kira WHERE uname = ? AND pass = ?";
		//System.out.println("Your user name is "+userName);
		//System.out.println("Your password is "+password);
		//System.out.println("Querry "+querry);
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(  
					"jdbc:oracle:thin:@localhost:1521:xe", "user1", "sharma");
			PreparedStatement stmt = con.prepareStatement(querry);
			stmt.setString(1,userName);
			stmt.setString(2,password);
			ResultSet rs = stmt.executeQuery();
			boolean more = rs.next();
			if(!more){
				return false;
				
			}
			else if(more){
				return true;
			}
			
		}catch(Exception e){
			System.out.println("line number 30"+e);
		}
		return false;
	}
}
