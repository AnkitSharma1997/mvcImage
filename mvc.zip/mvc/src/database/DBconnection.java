package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class DBconnection {
	public static Connection createConnection(Connection con){
		try{Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "user1", "sharma");
		//Statement stmt = con.createStatement();
		}catch(Exception e){
			System.out.println(e);
		}
		return con;
	}
}
