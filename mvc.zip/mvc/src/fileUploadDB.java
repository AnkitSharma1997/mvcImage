

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig
public class fileUploadDB extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String category = request.getParameter("category");
		String brand = request.getParameter("brand");
		String price = request.getParameter("price");
		String desc = request.getParameter("desc");
		Part part = request.getPart("file");
		InputStream inputStream = null ;
		if(part !=null){
			 inputStream = part.getInputStream();
			 
		}
		
		System.out.println(inputStream == null);
		
		try {
			
			//String image = request.getParameter("attach");

			String querry = "insert into Product values(?,?,?,?,?,?,?)";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "user1", "sharma");
			PreparedStatement ps = con.prepareStatement(querry);
			
			
			if(inputStream != null){
				System.out.println("value of part is not null");
		        ps.setBlob(7,inputStream );
			}
			
			ps.setInt(1, id);
			ps.setString(2,name );
			ps.setString(3, category);
			ps.setString(4, brand);
			ps.setString(6, desc);
			ps.setString(5, price);
			///File f = new File(image);  
			//FileReader fr=new FileReader(f); 
			
			int i = ps.executeUpdate(); 
			if(i>0){
				System.out.println(i+"  inserted a record");
			}
		} catch (Exception e) {
			
			System.out.println(e);
		}
		finally{
			request.getRequestDispatcher("LogIn.jsp").forward(request,response);
		}
		
	}
		

	

}
