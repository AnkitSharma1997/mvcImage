
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mvc.LoginBeans;


public class loginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		response.setContentType("text/html");
		String UserName = request.getParameter("username");
		String Password = request.getParameter("password");
		PrintWriter out = response.getWriter();
		LoginBeans user = new LoginBeans();
		user.setUserName(UserName);
		user.setPassword(Password);
		if (!UserDAO.login(user)) {

			out.print("you are not register user Please Sign up first...");
			out.println("<br><br>");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.include(request, response);

		} else {
			HttpSession session = request.getSession(true);
			session.setAttribute("username", UserName);
			
			RequestDispatcher rd = request.getRequestDispatcher("LogIn.jsp");
			rd.forward(request, response);

		}

	}

}
